#ifndef ARV_B
#define ARV_B

#include <stdio.h>
#include <stdlib.h>
#include "manipulacao_dados.h"
#include "abordagem_dinamica.h"

#define TAMANHO_NO 60
#define MAX_NRO 3
#define TAMANHO_CABECALHO 60

//Typedef das estruturas de dados para o arquivo de índice
typedef struct no_Arvb NO_ARVB;
typedef struct arvB ARVB;
typedef struct registro_cabecalho CABECALHO;
typedef struct registro_dados DADOS;

//Typedef de estrututra auxiliar
typedef struct promocao_no PROMOCAO;

//Definição das funcionalidades

/**
 * @brief Inicializa a árvore B
 * 
 * @param void
 * @return ARVB*
*/
ARVB * init_arvB(void);

/**
 * @brief Inicializa um nó da árvore B
 * 
 * @param void
 * @return NO_ARVB*
*/
NO_ARVB * init_no(void);

/**
 * @brief Função que insere um registro na árvore B
 * 
 * @param arquivo Arquivo de dados
 * @param arv Árvore B
 * @param status Status a ser definido para o arquivo
 * 
 * @return void
*/
void set_status_arvB(FILE *arquivo, char status, ARVB *arv);


/**
 * @brief Função que cria um arquivo de indice seguindo a estrutura de arvoreB* 
 * @param arquivo Arquivo de dados
 * @param arv Árvore B
 * @param status Status a ser definido para o arquivo
 * 
 * @return void
*/
void construcao_arvB(FILE *arquivo_dados, FILE *arquivo_index, CABECALHO *registro_cabecalho_dados);

/**
 * @brief Função que busca um registro por id na árvore B
 * 
 * @param index Arquivo de índice
 * @param id id a ser buscado
 * 
 * @return long int;
*/
long int busca_arvB(FILE *index, int id, ARVB *cabecalho);


/**
 * @brief Função que busca um registro por id na árvore B
 * 
 * @param index Arquivo de índice
 * @param id id a ser buscado
 * 
 * @return ARVB*;
*/
ARVB* ler_cabecalho_arvB(FILE* arquivo);

/**
 * @brief Função que busca um registro por id na árvore B
 * 
 * @param index Arquivo de índice
 * @param id id a ser buscado
 * 
 * @return ARVB*;
*/
void inserir_arvB(FILE* arquivo_index, ARVB* arvore, int chave, long int byteoffset);

/**
 * @brief Função que escreve o cabeçalho da árvore B no arquivo de indice
 * 
 * @param arquivo Arquivo de índice
 * @param arvore Ponteiro para a Árvore B (cabeçalho)
 * 
 * @return void
 */
void escrever_cabecalho_arvB(FILE* arquivo, ARVB* arvore);


#endif