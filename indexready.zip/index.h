#ifndef INDEX_H
    #define INDEX_H

#include "utils.h" 
#include "vetorIndex.h"

//Struct definitions for index file
typedef struct registro_cabecalho_index CABECALHO_INDEX;
typedef struct registro_dados_index DADOS_INDEX;

#define TAMANHO_REGISTRO_INDEX 13
#define TAMANHO_VETOR_INDEX 1010

//Function definitions

/**
 * @brief 
 * 
 * @param 
 * @return 
 */
void funcionalidade4(void);

/**
 * @brief 
 * 
 * @param 
 * @return 
 */
void funcionalidade5(void);

/**
 * @brief 
 * 
 * @param 
 * @return 
 */
void funcionalidade6(void);


#endif